<?php 
	session_start();
	include 'include/connection.php';
	
?>

  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>الملف الشخصي</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <div class="vertical-menu">
		 <a href="profile.php">الملف الشخصي</a>
		 <a href="messages.php">&#9993; المحادثات</a>
		 <a href="advertisements.php">&#9872; اعلاناتي</a>
		 <a href="orders.php">&#128448; طلباتي</a>
		 <a href="reservations.php">&#9745; حجوزاتي</a>
		 <a href="advertisementAdd.php">&#10011; اضافة اعلان جديد</a>
		 <a href="fav.php">&#10084; المفضلة</a>
		 <a href="index.php">تسجيل الخروج</a>
    </div>
    <?php
	$query = "SELECT * FROM `users` WHERE email='$email'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
    ?>
    <center>
    <div class="class2" style="margin-top:-650px;">
		<div class="text2" style="text-align:right;">
			<h1>معلومات ملفك الشخصي</h1>
			<div align="left">
			<form method="post" action="updateUser.php?id=<?php echo $row['id']; ?>">
			<table border="0" class="table1" style="margin-left:-75px;">
			<tr>
				<td>الجنس<br><br>
				<select name="gender">
						<option value="<?php echo $row['gender']; ?>" hidden><?php echo $row['gender']; ?></option>
						<option value="ذكر">ذكر</option>
						<option value="انثى">انثى</option>
				</select><br>
				</td>
				<td>المسمى الوظيفي<br><br>
				<select name="job">
						<option value="<?php echo $row['job']; ?>" hidden><?php echo $row['job']; ?></option>
						<option value="طالب جامعي">طالب جامعي</option>
						<option value="موظف">موظف</option>
						<option value="عاطل عن العمل">عاطل عن العمل</option>
				</select><br>
				</td>
			</tr>
			<tr>	
				<td style="width:200px;">هل انت شخص مدخن؟<br>
				<select name="smoke">
						<option value="<?php echo $row['smoke?']; ?>" hidden><?php echo $row['smoke?']; ?></option>
						<option value="نعم">نعم</option>
						<option value="لا">لا</option>
				</select><br>
				</td>
				<td><br>هل تمتلك حيوان أليف؟<br>
				<select id="animal" name="Selectanimal" onchange="changeFUnction()">
						<option value="<?php echo $row['Has_Animal?']; ?>" ><?php echo $row['Has_Animal?']; ?></option>
						<option value="طيور">طيور</option>
						<option value="قطة">قطة</option>
						<option value="سمكة">سمكة</option>
						<option value="لا يوجد">لا يوجد</option>
						<option value="حيوان آخر">حيوان آخر</option>
				</select>
			<input id="specifyInput" name="animal" type="text" placeholder="" style="visibility:hidden; width:125px;" />

				
			</tr>
		</table>
		</div>
		<br><br>
		<div align="right"> 
		<table border=0 class="table1" style="margin-top:-350px;">
			<tr>
				<td>الإسم الأول</td>
				<td>الإسم الأخير</td>
				<td>العمر</td>
			</tr>
			<tr>
				<td><input type="text" name="fname" value="<?php echo $row['fname']; ?>" style="width:150px;"></td>
				<td><input type="text" name="lname" value="<?php echo $row['lname']; ?>" style="width:150px;"></td>
				<td><input type="text" name="age"   value="<?php echo $row['age']; ?>"style="width:150px;"></td>
			</tr>
		</table>
		<br><br>
		    <h4>البريد الإلكتروني *</h4><br>
		    <input type="email" name="email" value="<?php echo $row['email']; ?>" placeholder="example@gmail.com" required><a href=""><button type="button" class="btn2" value="تحقق">تحقق</button></a><br>
		    <br>
		    <h4>رقم الجوال</h4>
		    <input type="text" name="mobile" value="<?php echo $row['phone']; ?>" placeholder="5xx xxx xxx"><a href="check.php"><button class="btn2" value="تحقق">تحقق</a></button>
		    <br><br>
		   <input type="submit" class="btn2" name="submit" value="حفظ">
		   </form>
		<?php }
	}
	?>
		   <br><br><br>
		   </div>
		</div>
	</div>
	</center>
	<script>
		function changeFUnction()
		{
		    if(animal.value=="حيوان آخر")
			 specifyInput.style["visibility"]="visible";
		    else
			 specifyInput.style["visibility"]="hidden";

		}
	</script>
<div class="footer">
</div>
</body>
</html>

