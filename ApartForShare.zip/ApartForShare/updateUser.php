<?php
	include 'include/connection.php';

	if(isset($_POST["fname"]) and isset ($_POST["lname"]) and isset ($_POST["mobile"]) and isset ($_POST["email"]) and isset ($_POST["gender"]))
	{
		$id=$_GET["id"];
		$gender= $_POST["gender"];
		$job= $_POST["job"];
		$smoke= $_POST["smoke"];
		$fname= $_POST["fname"];
		$lname= $_POST["lname"];
		$age= $_POST["age"];
		$animal=$_POST["animal"];
		if($animal=="")
			$animal=$_POST["Selectanimal"];
		$email= $_POST["email"];
		$mobile= $_POST["mobile"];
	$sql="UPDATE `users` SET `fname`='$fname',`lname`='$lname',`email`='$email',
	`phone`='$mobile',`gender`='$gender',`age`='$age',`job`='$job',`smoke?`='$smoke' 
	,`Has_Animal?`='$animal' WHERE `id`='" . $id . "'" ;
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");

	if (mysqli_query($connect, $sql)) {
		echo "<script>alert('تم التعديل بنجاح');";
		echo "window.location.href = 'profile.php'";
		echo "</script>";
	} else {
		echo "<script>alert('فشل التعديل');";
		echo "window.location.href = 'profile.php'";
		echo "</script>";
	}
	}
	mysqli_close($connect);
?>