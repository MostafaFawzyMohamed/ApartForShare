  <?php
	session_start();		
	include 'include/connection.php';
	$query = "SELECT * FROM `users`";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));

  ?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>المستخدمين</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/adminHeader.php'; ?>
    <center>
   
    <div class="class2" style="background-color:#b2b2b2;">
		<div class="text2" style="text-align:right; color:black;"> 
		    <h1>لوحة التحكم / الملف الشخصي</h1>
		    <table border=1 style="border-bottom: 1px black #ddd;">
				<tr>
					<td>الاسم</td>
					<td>البريد الإلكتروني</td>
					<td>رقم الهاتف</td>
					<td>العملية</td>
				</tr>
			 <?php
			    if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {

			    ?>
				<tr>
					<td><?php echo $row['fname']. " " . $row['lname']; ?></td>
					<td><?php echo $row['email']; ?></td>
					<td><?php echo $row['phone']; ?></td>
					<td><button class="btn4" style="width:150px;" value="تعليق">تعليق</button>
					<button class="btn4" style="width:150px;" value="إزالة التعليق">إزالة التعليق</button>
					&nbsp; <a href="deleteUser.php?id=<?php echo $row['id']; ?>"><img src="delete.png" style="height:35px;"/></a></td>
				</tr>
			    <?php } } ?>
		    </table>
		   <br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

