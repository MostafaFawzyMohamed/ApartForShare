<?php
session_start();
include 'include/connection.php';
$email="";
$user_id=0;
if(isset($_SESSION['email']))
	$email=$_SESSION['email'];
if(isset($_GET["Appartment_id"]))
{
	$Appart_id=$_GET['Appartment_id'];
	$query = "SELECT * FROM `users` WHERE email='$email'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$user_id=$row['id'];
		}
	}
	
	$sql="INSERT INTO `favorite` (`id`, `appart_id`, `user_id`) 
		VALUES (NULL, '$Appart_id', '$user_id');";	
	if (mysqli_query($connect, $sql)) {
		echo "<script>alert('تم الإضافة بنجاح');";
		echo "window.location.href = 'Fav.php'";
		echo "</script>";
	}
	else{
		echo "<script>alert('فشل الإضافة !!');";
		echo "window.location.href = 'accommodationRequest.php'";
		echo "</script>";

	}
	 mysqli_close($connect);
	
}

?>

