<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_GET['Appartment_id'])){
		$Appartment_id=$_GET['Appartment_id'];
	}
	$query = "SELECT * FROM `comments` WHERE status='مقبول'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	
?>  
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>التقييمات والتعليقات</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
     <?php include 'include/userHeader.php'; ?>
    <center>
    <div class="class2" style="width:1250px;">
    <br><br>
		<div class="text2" style="text-align:right;">
			<div class="scrollmenu">
			  <a href="Specifications.php?Appartment_id=<?php echo $Appartment_id; ?>" >المواصفات</a>
			  <a href="Rating.php?Appartment_id=<?php echo $Appartment_id; ?>" style="color:gray;">التقييمات والتعليقات</a>
			  <a href="rules.php?Appartment_id=<?php echo $Appartment_id; ?>">شروط الحجز والإلغاء</a>
			  <a href="ResidentSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>">مواصفات المقيم في السكن</a>
			  <a href="RequestSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>">قم بتحديد مواصفات شريك السكن المرغوب</a>
			  
		</div>
			<br><br>
			<div align="right"> 
			<table border=0 class="table2" >
			<?php 
				if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
						if($row['id']==4){
			?>
				<tr>
					<td class="td2">
						<strong><p style="font-size:20px;">
						<img src="profile1.png" style="width:50px; height:50px;"/>
						<?php echo $row['name']; ?> <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						<br>
						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <?php echo $row['comment']; ?><br><br>
						<img src="profile3.png" style="width:25px; height:25px; margin-right:70px;"/>
						&nbsp; شكراً على إهتمامك سعدنا بخدمتك</p><br><br><br><br><br><br><br><br><br><br></strong>
						<p style="font-size:15px; text-align:left; color:gray; margin-top:-450px;"></p>
						<a href="ResponseRate.php?Appartment_id=<?php echo $Appartment_id; ?>&id=<?php echo $row['id']; ?>"><button class="button btn1" style="margin-right:700px; height:50px; width:200px;" value="رد"/>رد</button></a><br>
						<br><br>
					</td>
				</tr>
						<?php } 
						else {
						?>
						<tr>
					<td class="td2">
						<strong><p style="font-size:20px;">
						<img src="profile1.png" style="width:50px; height:50px;"/>
						<?php echo $row['name']; ?> <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						<br>
						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <?php echo $row['comment']; ?><br><br>
						<br><br><br><br><br><br><br><br><br><br><br><br><br></strong>
						<p style="font-size:15px; text-align:left; color:gray; margin-top:-450px;"></p>
						<a href="ResponseRate.php?Appartment_id=<?php echo $Appartment_id; ?>&id=<?php echo $row['id']; ?>"><button class="button btn1" style="margin-right:700px; height:50px; width:200px;" value="رد"/>رد</button></a><br>
						<br><br>
					</td>
				</tr>
				<?php } }} ?>
				
			</table>
			<br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

