<?php 
	session_start();	
	include 'include/connection.php';
	$id=0;

?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>اضافة مشرف</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/adminHeader.php'; ?>
    <center>
   
    
    <div class="class2">
		<div class="text2" style="text-align:right;">
		<form method="post" action="addNewAdmin.php">
		    <h1>اضافة مشرف جديد</h1>
		    <h4>الإسم *</h4>
		    <input type="text" name="name" placeholder="Name"><br>
		    <h4>البريد الإلكتروني *</h4>
		    <input type="email" name="email" placeholder="example@gmail.com"><br>
		    <h4>رقم الجوال *</h4>
		    <input type="text" name="mobile" placeholder="5xx xxx xxx"><br>
		    <h4>الرقم السري *</h4>
		    <input type="password" name="password" placeholder="********"><br><br><br>
		    <input type="submit" class="btn1" style="color:black; width:200px;" value="إضافة مشرف"/>
		</form>

	
		   <br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

