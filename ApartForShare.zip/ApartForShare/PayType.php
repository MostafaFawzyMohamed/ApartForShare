<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_GET['Appartment_id'])){
		$Appartment_id=$_GET['Appartment_id'];
	}
?> 
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>توع عملة الدفع</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
		    <h1 style="color:black">المراجعة والدفع</h1>
		    <h2>قم بإختيار طريقة الدفع المناسبة</h2><br>
		     <?php
			$user_id=0;
			$query = "SELECT * FROM `users` WHERE email='$email'";
			mysqli_query($connect,"SET CHARACTER SET 'utf8'");
			$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
			if ($result->num_rows > 0) {
				// output data of each row
				while($row = $result->fetch_assoc()) {
					$user_id=$row['id'];
				}
			}
		    ?>
		    <form method="post" action="Pay.php">
		    <input type="number" name="id" value="<?php echo $user_id; ?>" hidden />
		    <input type="number" name="Appart_id" value="<?php echo $Appartment_id; ?>" hidden />
		    <input type="radio" name="type" value="card"/>الدفع بالبطاقة<br>
		    <div style="margin-right:50px;">
		    <img src="mada.png" style="height:25px;"/>
		    <img src="mastercard.png" style="height:50px;"/>
		    </div>
		    <br>
		    <input type="radio" name="type" value="ApplePay"/>Apple Pay<br>
		    <div style="margin-right:50px;">
		    <img src="Applepay.png" style="height:25px;"/>
		    </div><br><br>
		    <button type="submit">متابعه</button></a>
		   </form>
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

