<?php
	include 'include/connection.php';

	$id=$_GET["id"];
	
	$sql = "DELETE FROM `users` WHERE `id`='" . $id . "'";

	if(mysqli_query($connect, $sql)){
		echo "<script>alert('تم الحذف بنجاح');";
		echo "window.location.href = 'users.php'";
		echo "</script>";
	}
	else{
		echo "<script>alert('فشل الحذف !!');";
		echo "window.location.href = 'users.php'";
		echo "</script>";
	}
	mysqli_close($connect);
?>