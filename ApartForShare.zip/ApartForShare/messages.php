<?php 
	session_start();
	include 'include/connection.php';
	
?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>المحادثات</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
   <div class="vertical-menu">
		 <a href="profile.php">الملف الشخصي</a>
		 <a href="messages.php">&#9993; المحادثات</a>
		 <a href="advertisements.php">&#9872; اعلاناتي</a>
		 <a href="orders.php">&#128448; طلباتي</a>
		 <a href="reservations.php">&#9745; حجوزاتي</a>
		 <a href="advertisementAdd.php">&#10011; اضافة اعلان جديد</a>
		 <a href="fav.php">&#10084; المفضلة</a>
		 <a href="index.php">تسجيل الخروج</a>
    </div>
    <?php
	$query = "SELECT * FROM `users` WHERE email='$email'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$id=$row['id'];
	$query2 = "SELECT * FROM `messages` WHERE user_id='$id'";
	$result2 = mysqli_query($connect, $query2) or die(mysqli_error($connect));
    ?>
    <center>
    <div class="class2" style="margin-top:-650px;">
		<div class="text2" style="text-align:right;">
			<h1>&#9993; محادثاتي</h1>
			<div align="right"> 
			<table border=0 class="table2">
			<?php
			if ($result2->num_rows > 0) {
				// output data of each row
				while($row2 = $result2->fetch_assoc()) {
			?>
				<tr>
					<td class="td">
						<strong><p style="font-size:27px;"><?php echo $row2['name']; ?></strong>
						&nbsp; &nbsp; &nbsp;<img src="<?php echo $row2['img']; ?>" style="width:100px; height:100px;"/></p>
						<p style="font-size:15px; text-align:right; color:gray; margin-top:-100px;"><?php echo $row2['time']; ?></p></p>
					</td>
				</tr>
			<?php } } } }?>
			</table>
			<br><br><br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

