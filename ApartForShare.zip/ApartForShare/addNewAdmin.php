<?php
include 'include/connection.php';
if(isset($_POST["name"]) and isset ($_POST["email"]) and isset ($_POST["password"]) and isset ($_POST["mobile"]))
{
	$name = $_POST['name'];
	$password = $_POST['password'];
	$email = $_POST['email'];
	$phone = $_POST['mobile'];
	$sql="INSERT INTO `admin` (`id`, `name`, `email`,`password`,`phone`) VALUES (NULL, '$name', '$email', '$password', '$phone');";	
	if (mysqli_query($connect, $sql)) {
		echo "<script>alert('تم الإضافة بنجاح');";
		echo "window.location.href = 'ManageProfile.php'";
		echo "</script>";
	}
	else{
		echo "<script>alert('فشل الإضافة !!');";
		echo "window.location.href = 'ManageProfile.php'";
		echo "</script>";

	}
	 mysqli_close($connect);
	
}

?>

