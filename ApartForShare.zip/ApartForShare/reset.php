  <?php 
	session_start();
	$email=$_SESSION["email"];
  ?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>استعادة كلمة المرور</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <div id="cat">
     <ul>
		<a href="index.php" ><img src="logo.png" align="right" style="margin-right:40px; margin-top:30px; height:150px; width:150px"></a>
		<li id="Home" class="active filter"><a href="index.php">الرئيسية</a></li>
		<li id="Services" class=" filter"><a href="about.php">من نحن</a></li>
		<li id="Contact" class=" filter"><a href="contact-us.php">تواصل معنا</a></li> 
		<li id="Login" class=" filter"><a href="Login.php">التسجيل / تسجيل الدخول</a></li> 
		<li id="" class=" filter"><a href="#">English</a></li> 
	</ul>
    </div>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
		<form method="post" action="updatePass.php">
		    <input type="email" name="email" value="<?php echo $email; ?>" hidden>
		    <h4>ادخل كلمة المرور الجديدة</h4>
		    <input type="password" name="password" placeholder="*********">
		    <h4>تأكيد كلمة المرور</h4>
		    <input type="password" name="cpass" placeholder="*********">
		    <br><br><br><br>
		    <center>
		    <input type="submit" class="button btn2" value="حفظ">
		   </form>
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

