<?php 
	session_start();		
?>
<!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>لوحة التحكم</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    	<?php include 'include/adminHeader.php'; ?>
    <h2 style="color:white; margin-right:300px;">لوحة التحكم</h1>
    <div class="class2" style="background-color:white; width:300px; height:250px; margin-right:300px;">
		    <p style="color:gray; font-size:32px;">إدارة المشرفين</p>
		    <strong><p style="font-size:30px;">يمكنك إضافة وحذف مشرف</p></strong>	
		    <br><br><br>
		    <a href="ManageProfile.php"><button style="height:40px; width:100px; margin-right:175px;">المزيد</button></a>		   
	</div>
	<div class="class2" style="background-color:white; width:300px; height:250px; margin-top:-250px; margin-right:650px;">
		    <p style="color:gray; font-size:32px;">إدارة المستخدمين</p>
		    <strong><p style="font-size:30px;">يمكنك ادارة المستخدمين المسجلين</p></strong>	
		    <br>
		    <a href="users.php"><button style="height:40px; width:100px; margin-right:175px;">المزيد</button></a>
		   
		   <br><br><br>
	</div>
	<div class="class2" style="background-color:white; width:300px; height:250px; margin-top:-250px; margin-right:1000px;">
		    <p style="color:gray; font-size:32px;">ادارة الإعلانات</p>
		    <strong><p style="font-size:30px;">يمكنك ادارة الإعلانات ومتابعتها</p></strong>	
		    <br>
		    <a href="adsManage.php"><button style="height:40px; width:100px; margin-right:175px;">المزيد</button></a>
		   
		   <br><br><br>
	</div><br>
	<div class="class2" style="background-color:white; width:300px; height:250px; margin-right:300px;">
		    <p style="color:gray; font-size:32px;">التقييمات والتعليقات</p>
		    <strong><p style="font-size:30px;">يمكنك متابعة التقييمات والتعليقات</p></strong>	
		    <br>
		    <a href="Ratings.php"><button style="height:40px; width:100px; margin-right:175px;">المزيد</button></a>
		   
		   <br><br><br>
	</div>
<div class="footer">
</div>
</body>
</html>

