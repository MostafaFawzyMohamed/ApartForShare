  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>التوثيق</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <div id="cat">
     <ul>
		<a href="index.php" ><img src="logo.png" align="right" style="margin-right:40px; margin-top:30px; height:150px; width:150px"></a>
		<li id="Home" class="active filter"><a href="index.php">الرئيسية</a></li>
		<li id="Services" class=" filter"><a href="about.php">من نحن</a></li>
		<li id="Contact" class=" filter"><a href="contact-us.php">تواصل معنا</a></li> 
		<li id="Login" class=" filter"><a href="Login.php">التسجيل / تسجيل الدخول</a></li> 
		<li id="" class=" filter"><a href="#">English</a></li> 
	</ul>
    </div>
    <center>
    <div class="class3">
    
		    <h2 style="color:black;">تم توثيق حسابك بنجاح</h2><br><br>
		    <h2 style="font-size:100px;">&#x2705;</h2>
		    <br><br><br>
		    <a href="AdminPannel.php"><button style="height:50px;">استمرار</button></a>
		   
		   <br><br><br>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

