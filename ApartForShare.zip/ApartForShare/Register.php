  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>حساب جديد</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
     <?php include 'include/header.php' ?>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
		    <h1>قم بإدخال المعلومات التالية</h1>
		    <form method="post" action="confirmed.php">
		    <h4>الإسم الأول</h4>
		    <input type="text" name="fname" placeholder=""><br>
		    <h4>الإسم الأخير</h4>
		    <input type="text" name="lname" placeholder=""><br>
		    <h4>البريد الإلكتروني *</h4>
		    <input type="email" name="email" value="<?php echo $_GET['email']; ?>"><br>
		    <div align="left" style="margin-top:-270px;">
		    <h4>كلمة المرور *</h4>
		    <input type="password" name="pass" placeholder="********" required><br>
		    <h4>تأكيد كلمة المرور *</h4>
		    <input type="password" name="Cpass" placeholder="********" required><br>
		    </div>
		    <br><br><br><br>
		    <center><input type="checkbox" name="check1" value="1">
			<label for="check1">انا اوافق على <a href="Terms.php" style="color:red;">سياسة الشروط والاحكام  وسياسة الحجز</a></label>
		    <br><br>
			<input type="submit" class="btn2" name="submit" value="تسجيل دخول">
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

