<?php 
	session_start();
	include 'include/connection.php';
	
?> 
 <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>طلب سكن</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
	<?php include 'include/userHeader.php'; ?>
    
    <center>
    
    <div class="class4">
    <div class="text2" >
		<div style="background-color:#b2b2b2; height:150px;">
			<table class="table1" align="right" style="width:700px; color:black;">
				<tr>
					<td>المدينة</td>
					<td>الحي</td>
					<td colspan="2"><p style="color:white; font-size:15px;">تاريخ عرض الإعلان</p></td>
				</tr>
				<tr>
					<td>
						<select name="ch1" style="background-color:#b2b2b2; height:85px;"><img style="width:20px;" src="location.png"/>
						<option value="الجميع">الجميع</option>
						<option value="الطائف">الطائف</option>
						<option value="مكه">مكه</option>
						<option value="جده">جده</option>
						<option value="الرياض">الرياض</option>
					</td>
					<td>
						<select name="ch1" style="background-color:#b2b2b2; height:85px;"><img style="width:20px;" src="location.png"/>
						<option value="الجميع">الجميع</option>
						<option value="الطائف">الطائف</option>
						<option value="مكه">مكه</option>
						<option value="جده">جده</option>
						<option value="الرياض">الرياض</option>
					</td>
					<td>
						<label style="color:white;">من</label><br>
						<input type="date" name="ch1" style="background-color:#b2b2b2; border-radius:20px; font-size:15px; width:125px; height:50px;">
					<td>
						<label style="color:white;">إلى</label><br>
						<input type="date" name="ch1" style="background-color:#b2b2b2; border-radius:20px; font-size:15px; width:125px; height:50px;">						
					</td>
				</tr>
			</table>
			<br>
			<a href=""><img src="search.png" style="height:40px; margin-right:70px;"/></a>
		</div>
     </div>
     <br><br>
     <?php
	$query = "SELECT * FROM `ads` WHERE status='مقبول'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	if ($result->num_rows > 0) {
				// output data of each row
				while($row = $result->fetch_assoc()) {
	?>
	<div class="class4">
		<div class="text2" style="text-align:right;">
			<img src="<?php echo $row['img']; ?>" style="height:650px; width:700px; margin-right:-350px"/>
		</div>
	</div>
		<div class="text3" style="margin-top:-660px;">
			<strong><p style="margin-right:20px;"><?php echo $row['type']; ?><br>
			<img style="width:20px;" src="location.png"/><?php echo $row['location']; ?></strong><br>
			&nbsp; &nbsp;<i>مساحة الوحدة (<?php echo $row['area']; ?> م2)</i>
			</p>
			<br><br><br><br><br>
			<p style="margin-right:20px; color:gray">السعر</p>
			<i><p style="margin-right:20px;"><?php echo $row['price']; ?> ريال / في الشهر</p></i>
			<div style="margin-right:275px;">
				<a href="contactHost.php?Appartment_id=<?php echo $row['id']; ?>"><button class="btn1" style="">تواصل</button></a><br><br>
				<a href="Specifications.php?Appartment_id=<?php echo $row['id']; ?>"><button class="btn1">عرض التفاصيل</button></a><br><br>
				<a href="AddFav.php?Appartment_id=<?php echo $row['id']; ?>"><button class="btn1"><img src="fav.png" style="width:80px; height:80px;"/></button></a>
				
			</div>
		</div>
		<br><br><br>
		<?php } } ?>
	</center>
<div class="footer">
</div>
</body>
</html>

