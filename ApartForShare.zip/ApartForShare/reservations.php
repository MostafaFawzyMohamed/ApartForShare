<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_SESSION['email']))
		$email=$_SESSION['email'];
	$user_id=0;
	$query = "SELECT * FROM `users` WHERE email='$email'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$user_id=$row['id'];
		}
	}
	
?> 
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>الحجوزات</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <div class="vertical-menu">
		 <a href="profile.php">الملف الشخصي</a>
		 <a href="messages.php">&#9993; المحادثات</a>
		 <a href="advertisements.php">&#9872; اعلاناتي</a>
		 <a href="orders.php">&#128448; طلباتي</a>
		 <a href="reservations.php">&#9745; حجوزاتي</a>
		 <a href="advertisementAdd.php">&#10011; اضافة اعلان جديد</a>
		 <a href="fav.php">&#10084; المفضلة</a>
		 <a href="index.php">تسجيل الخروج</a>
    </div>
    <center>
    <div class="class4" style="margin-top:-650px;">
		
		 <?php
			$sql = "SELECT * FROM `reservations` WHERE user_id='$user_id'";
			mysqli_query($connect,"SET CHARACTER SET 'utf8'");
			$result2 = mysqli_query($connect, $sql) or die(mysqli_error($connect));
			if ($result2->num_rows > 0) {
				// output data of each row
				while($row2 = $result2->fetch_assoc()) {
					$Appartment_id=$row2['appart_id'];
					$reservation_id=$row2['id'];
					$sql2 = "SELECT * FROM `ads` WHERE id='$Appartment_id'";
					mysqli_query($connect,"SET CHARACTER SET 'utf8'");
					$result3 = mysqli_query($connect, $sql2) or die(mysqli_error($connect));
					if ($result3->num_rows > 0) {
						// output data of each row
						while($row3 = $result3->fetch_assoc()) {
					
		    ?>
		    <br><br>
			<img src="<?php echo $row3['img']; ?>" style="height:650px; width:700px; margin-right:-500px"/>
		<div class="text3" style="margin-top:-650px;">
			<strong><p style="margin-right:20px;"><?php echo $row3['type']; ?><br>
			<img style="width:20px;" src="location.png"/><?php echo $row3['location']; ?></strong><br>
			&nbsp; &nbsp;<i>مساحة الوحدة (<?php echo $row3['area']; ?> م2)</i>
			</p>
			<br><br><br><br><br>
			<p style="margin-right:20px; color:gray">السعر</p>
			<i><p style="margin-right:20px;"><?php echo $row3['price'];; ?> ريال / في الشهر</p></i>
			<div style="margin-right:275px;">
				<a href="ReservationsDetails.php?id=<?php echo $reservation_id; ?>"><button class="btn1" style="width:200px;">عرض تفاصيل الطلب</button></a><br><br>
				<a href="CancelReservation.php?id=<?php echo $reservation_id; ?>"><button class="btn1" style="width:200px;">الغاء الطلب</button></a>
			</div>
			
		</div>
		
			<?php } } } } ?>
			
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

