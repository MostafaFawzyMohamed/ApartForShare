    <?php
	session_start();		
	include 'include/connection.php';
	$query = "SELECT * FROM `comments` WHERE status='مقبول'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));

  ?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>التقييمات والتعليقات</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
         	<?php include 'include/adminHeader.php'; ?>

    <center>
    
    <div class="class2" style="width:1650px;">
    <br><br><br>
    <div class="text2" style="text-align:center;">
			<div class="scrollmenu">
			  <a href="ratings.php">التعليقات الحديثه</a>
			  <a href="ratings2.php" style="color:gray;">التعليقات التي تمت مراجعتها ونشرها</a>
			  <a href="ratings3.php">التعليقات التي تمت مراجعتها ورفضها</a>
			  
		</div>
    <br><br><br>
				
			<div align="right"> 
			<table border=0 class="table2" >
			<?php
					if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {

			?>
				<tr>
					<td class="td2">
						<strong><p style="font-size:20px;">
						<img src="profile1.png" style="width:50px; height:50px;"/>
						<?php echo $row['name']; ?> <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						<br>
						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <?php echo $row['comment']; ?><br><br>
						<br><br><br><br><br><br><br><br><br><br></strong>
						<p style="text-align:left; color:black; margin-top:-375px;"></p>
						<a href="UpdateRating.php?id=<?php echo $row['id']; ?>&status=0;" style="font-size:25px; color:red;" ><button class="button btn1" style="margin-right:700px; height:50px; width:200px;" value="رفض"/>رفض</button></a>
					</td>
				</tr>
				<?php } } ?>
			</table>
			<br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

