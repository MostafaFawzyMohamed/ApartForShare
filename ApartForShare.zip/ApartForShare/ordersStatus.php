<?php 
	session_start();
	include 'include/connection.php';
	
?> 
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>حالة الطلب</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
     <div class="vertical-menu">
		 <a href="profile.php">الملف الشخصي</a>
		 <a href="messages.php">&#9993; المحادثات</a>
		 <a href="advertisements.php">&#9872; اعلاناتي</a>
		 <a href="orders.php">&#128448; طلباتي</a>
		 <a href="reservations.php">&#9745; حجوزاتي</a>
		 <a href="advertisementAdd.php">&#10011; اضافة اعلان جديد</a>
		 <a href="fav.php">&#10084; المفضلة</a>
		 <a href="index.php">تسجيل الخروج</a>
    </div>
    <center>
    <div class="class2" style="margin-top:-650px;">
		<div class="text2" style="text-align:right;">
			<h1>حالة الطلب</h1><br>
			<?php
				$query = "SELECT * FROM `users` WHERE email='$email'";
				mysqli_query($connect,"SET CHARACTER SET 'utf8'");
				$id=$_GET['id'];
				$query = "SELECT * FROM `orders` WHERE id='$id'";
				$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
				if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
			?>
			<div style="width:782px; height:100px; background-color:#b2b2b2; border-radius:30px;">
				<p>
				<p style="color:red; margin-right:25px;"><?php echo $row['status']; ?></p>
				<p style="color:red; margin-right:25px;"><?php echo $row['reason']; ?></p>
			</div><br><br>
			
			<div align="right">
			<center>
			<a href="UpdateAds.php?id=<?php echo $row['id']; ?>"><button class="btn1" style="font-size:20px; color:black" value="تعديل الطلب">تعديل الطلب</button>
			<a href="cancelOrder.php?id=<?php echo $row['id']; ?>"><button class="btn1" style="font-size:20px; color:black" value="استعراض سبب الرفض">إلغاء الطلب</button></a>
			<?php } } ?>
			<br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

