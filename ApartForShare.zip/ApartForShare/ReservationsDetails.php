<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_SESSION['email']))
		$email=$_SESSION['email'];
	
?> 
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>الحجوزات</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <div class="vertical-menu">
		 <a href="profile.php">الملف الشخصي</a>
		 <a href="messages.php">&#9993; المحادثات</a>
		 <a href="advertisements.php">&#9872; اعلاناتي</a>
		 <a href="orders.php">&#128448; طلباتي</a>
		 <a href="reservations.php">&#9745; حجوزاتي</a>
		 <a href="advertisementAdd.php">&#10011; اضافة اعلان جديد</a>
		 <a href="fav.php">&#10084; المفضلة</a>
		 <a href="index.php">تسجيل الخروج</a>
    </div>
    <center>

		 <?php
			if(isset($_GET['id']))
				$id=$_GET['id'];
			$sql = "SELECT * FROM `reservations` WHERE id='$id'";
			mysqli_query($connect,"SET CHARACTER SET 'utf8'");
			$result = mysqli_query($connect, $sql) or die(mysqli_error($connect));
			if ($result->num_rows > 0) {
				// output data of each row
				while($row = $result->fetch_assoc()) {
					
					
		    ?>
		<div class="text3" style="margin-top:-560px; margin-right:-150px; width:900px;">
			<br><strong>
			<p style="margin-right:20px; color:gray">نوع الدفع</p>
			<i><p style="margin-right:20px;"><?php echo $row['Payment_type']; ?></p></i>
			</strong>
			<br><br>
			<p style="margin-right:20px; color:gray">تاريخ انتهاء البطاقة</p>
			<i><p style="margin-right:20px;"><?php echo $row['expiry_date']; ?></p></i>
			<br><br>
			<p style="margin-right:20px; color:gray">إسم صاحب البطاقة</p>
			<i><p style="margin-right:20px;"><?php echo $row['Name']; ?></p></i>
			<div style="margin-right:575px;">
				<a href="Reservations.php"><button class="btn1" style="width:200px;">رجوع</button></a><br><br>
				<a href="CancelReservation.php"><button class="btn1" style="width:200px;">الغاء الطلب</button>
			</div>
		</div>
			<?php } } ?>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

