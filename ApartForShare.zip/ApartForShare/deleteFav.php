<?php
	include 'include/connection.php';

	$id=$_GET["Appartment_id"];
	
	$sql = "DELETE FROM `favorite` WHERE `id`='" . $id . "'";

	if(mysqli_query($connect, $sql)){
		echo "<script>alert('تم الحذف بنجاح');";
		echo "window.location.href = 'Fav.php'";
		echo "</script>";
	}
	else{
		echo "<script>alert('فشل الحذف !!');";
		echo "window.location.href = 'Fav.php'";
		echo "</script>";
	}
	mysqli_close($connect);
?>