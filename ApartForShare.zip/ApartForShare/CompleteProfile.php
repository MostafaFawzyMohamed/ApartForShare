<?php
include 'include/connection.php';
mysqli_query($connect,"SET CHARACTER SET 'utf8'");
$gender=$_POST['gender'];
$age=$_POST['age'];
$smoke=$_POST['smoke'];
$animal=$_POST['animal'];
$job=$_POST['job'];
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$sql = "UPDATE `users` SET 
	`phone`='$mobile',
	`gender`='$gender',
	`age`='$age',`job`='$job',`smoke?`='$smoke',
	`Has_Animal?`='$animal' WHERE `email`='$email'";
if(mysqli_query($connect, $sql)){
		session_start();
		$_SESSION["email"] = $email;
		header("Location: index2.php");
	}
?>