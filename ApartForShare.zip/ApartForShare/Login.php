  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>تسجيل الدخول كمستخدم</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
	<?php include 'include/header.php';?>
	<center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
		    <h1>اهلاً بك ..</h1>
		    <form method="post" action="ULog.php">
		    <h4>البريد الإلكتروني</h4>
		    <input type="email" name="email" placeholder="example@gmail.com"><br>
		    <h4>كلمة المرور</h4>
		    <input type="password" name="password" placeholder="********"><br>
		    <a href="resetpass.php"><h5 style="color:white;">نسيت كلمة المرور</h5></a>
		    
		    <input type="submit" name="submit" class="button btn2" value="تسجيل الدخول"/> &nbsp; &nbsp; 
		   </form>
		   <a href="create.php"><button class="button btn2">جديد</button></a>
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

