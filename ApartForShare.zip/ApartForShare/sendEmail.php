<html>
<body>
<?php
include 'include/connection.php';
function generateNumericOTP($n) { 
    $generator = "1357902468"; 
    $result = ""; 
    for ($i = 1; $i <= $n; $i++) { 
        $result .= substr($generator, (rand()%(strlen($generator))), 1); 
    }   
    // Return result 
    return $result; 
} 
if (isset($_REQUEST['email']))
//if "email" is filled out, send email
{
	$email = $_REQUEST['email'] ; 
	session_start();
	$_SESSION["email"] = $email;
	//send email
	include 'include/sendmail.php';
}
?>
</body>
</html>