  <?php 
	session_start();
	include 'include/connection.php';
	
?> 
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>اضافة اعلان</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <div class="vertical-menu">
		 <a href="profile.php">الملف الشخصي</a>
		 <a href="messages.php">&#9993; المحادثات</a>
		 <a href="advertisements.php">&#9872; اعلاناتي</a>
		 <a href="orders.php">&#128448; طلباتي</a>
		 <a href="reservations.php">&#9745; حجوزاتي</a>
		 <a href="advertisementAdd.php">&#10011; اضافة اعلان جديد</a>
		 <a href="fav.php">&#10084; المفضلة</a>
		 <a href="index.php">تسجيل الخروج</a>
    </div>
    <center>
    <div class="class2" style="margin-top:-650px;">
		<div class="text2" style="text-align:right;">
			<div align="center"> 
			<br><br><br><br><br><br>
			<a href="requestHousing.php"><button class="btn3" value="اعلان جديد عن سكن">اعلان جديد عن سكن</button></a>
			&nbsp; &nbsp; &nbsp;
			<a href="accommodationRequest.php"><button class="btn3" value="اعلان جديد عن طلب سكن">اعلان جديد عن طلب سكن</button></a>
			<br><br><br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

