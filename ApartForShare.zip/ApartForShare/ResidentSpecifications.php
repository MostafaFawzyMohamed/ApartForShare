<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_GET['Appartment_id'])){
		$Appartment_id=$_GET['Appartment_id'];
	}
	
?>  
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>مواصفات المقيم في السكن</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    
    <center>
    <div class="class2" style="width:1250px;">
    <br><br>
		<div class="text2" style="text-align:right;">
			<div class="scrollmenu">
			  <a href="Specifications.php?Appartment_id=<?php echo $Appartment_id; ?>">المواصفات</a>
			  <a href="Rating.php?Appartment_id=<?php echo $Appartment_id; ?>">التقييمات والتعليقات</a>
			  <a href="rules.php?Appartment_id=<?php echo $Appartment_id; ?>">شروط الحجز والإلغاء</a>
			  <a href="ResidentSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>" style="color:gray;">مواصفات المقيم في السكن</a>
			  <a href="RequestSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>">قم بتحديد مواصفات شريك السكن المرغوب</a>
			  
		</div>
			<br><br>
			<div align="right"> 
			<table border=0 class="table2" >
			<?php
				$query = "SELECT * FROM `resident`";
				mysqli_query($connect,"SET CHARACTER SET 'utf8'");
				$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
				if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
			?>
				<tr>
					<td class="td2">
						<strong><p style="font-size:20px;">
						<img src="profile1.png" style="width:50px; height:50px;"/>
						الإسم : <?php echo $row['name']; ?><br>
						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; الجنس: <?php echo $row['gender']; ?><br>
						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; العمر: <?php echo $row['age']; ?> سنة<br>
						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; المسمى الوظيفي : <?php echo $row['job']; ?><br>
						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <?php echo $row['smoke']; ?></p><br><br><br><br><br><br><br><br></strong>
						<p style="font-size:15px; text-align:left; color:gray; margin-top:-450px;"></p>
						<a href="contactResident.php?Appartment_id=<?php echo $Appartment_id; ?>&id=<?php echo $row['id']; ?>"><button class="button btn1" style="margin-right:700px; height:50px; width:200px;" value="تواصل"/>تواصل</button></a><br><br>
						<a href="rating2.php?Appartment_id=<?php echo $Appartment_id; ?>&id=<?php echo $row['id']; ?>"><button class="button btn1" style="margin-right:700px; height:50px; width:200px;" value="استعراض التقييمات"/>استعراض التقييمات</button></a><br>
						<br><br>
					</td>
				</tr>
				<?php } } ?>
			</table>
			<br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

