<?php
session_start();
include 'include/connection.php';
$email="";
$user_id=0;
if(isset($_GET['Appartment_id'])){
		$Appartment_id=$_GET['Appartment_id'];
	}
if(isset($_SESSION['email']))
	$email=$_SESSION['email'];
if(isset($_POST["comment_id"]) and isset($_POST['response']))
{
	$comment_id=$_POST['comment_id'];
	$response=$_POST['response'];
	$query = "SELECT * FROM `users` WHERE email='$email'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$user_id=$row['id'];
		}
	}
	
	$sql="INSERT INTO `responsecomment` (`id`, `comment_id`, `response`, `user_id`) 
		VALUES (NULL, '$comment_id', '$response' , '$user_id');";	
	if (mysqli_query($connect, $sql)) {
		echo "<script>alert('تم الإضافة بنجاح');";
		echo "window.location.href = 'rating.php?Appartment_id=$Appartment_id'";
		echo "</script>";
	}
	else{
		echo "<script>alert('فشل الإضافة !!');";
		echo "window.location.href = 'rating.php?Appartment_id=$Appartment_id'";
		echo "</script>";

	}
	 mysqli_close($connect);
	
}

?>

