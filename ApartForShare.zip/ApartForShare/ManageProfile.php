<?php 
	session_start();	
	include 'include/connection.php';
	$id=0;

?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>ادارة المستخدمين</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/adminHeader.php'; ?>
    <center>
    <?php
	$query = "SELECT * FROM `admin` WHERE email='$email'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$id=$row['id'];
    ?>
    
    <div class="class2">
		<div class="text2" style="text-align:right;">
		<form method="post" action="UpdateAdmin.php?id=<?php echo $id; ?>">
		    <h1>لوحة التحكم / الملف الشخصي</h1>
		    <h4>الإسم *</h4>
		    <input type="text" name="name" value="<?php echo $row['name']; ?>"><br>
		    <h4>البريد الإلكتروني *</h4>
		    <input type="email" name="email" value="<?php echo $row['email']; ?>" disabled><br>
		    <h4>رقم الجوال *</h4>
		    <input type="text" name="mobile" placeholder="5xx xxx xxx" value="<?php echo $row['phone']; ?>"><br><br><br>
		    <br><br>
		    <div style="margin-right:500px; margin-top:-400px;">
			<input type="submit" class="btn1" style="color:black; width:200px;" value="تعديل بيانات المشرف"/>
			</div>
		</form>
	<?php
		} 
	}
	?>
		<div style="margin-right:500px; ">
			<a href="addAdmin.php"><button class="btn1" style="color:black; width:200px;" value="اضافة مشرف">اضافة مشرف</button></a><br>
			<a href="deleteAdmin.php?id=<?php echo $id; ?>"><button class="btn1" style="color:black; width:200px;" value="حذف مشرف">حذف مشرف</button></a>
		</div>
	
		   <br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

