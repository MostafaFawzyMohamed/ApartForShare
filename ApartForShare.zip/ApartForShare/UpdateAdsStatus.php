<?php
	session_start();
	include 'include/connection.php';
	if(isset($_GET["status"]))
	{
		$id=$_GET["id"];
		$status= $_GET["status"];
		$sql="UPDATE `ads` SET `status`='$status' WHERE `id`='" . $id . "'" ;
		mysqli_query($connect,"SET CHARACTER SET 'utf8'");

		if (mysqli_query($connect, $sql)) {
			echo "<script>alert('تم التعديل بنجاح');";
			echo "window.location.href = 'adsManage.php'";
			echo "</script>";
		} else {
			echo "<script>alert('فشل التعديل');";
			echo "window.location.href = 'adsManage.php";
			echo "</script>";
		}
	}
	mysqli_close($connect);
?>
