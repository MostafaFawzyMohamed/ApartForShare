  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>حساب جديد</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
  <?php include 'include/header.php' ?>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
		    <h1>الشروط والأحكام</h1>
			<p style="font-size:20px;">توضح هذه البنود والشروط القواعد واللوائح الخاصة باستخدام موقعنا على الويب .<br>
			عبر وصولك واستخدامك موقع Apart for share ، فإنك توافق على قبولك، من غير تعديل أو قيود أو شروط على جميع الأحكام والشروط الواردة في هذه الاتفاقية. أنت تقر وتضمن حقك القانوني للدخول في هذه الاتفاقية واستخدام الموقع وفقاً لجميع الشروط والأحكام المتواجدة هنا . <br>
			اذا اتممت عملية حجز على موقع Apart for share ، فإنك ملتزم وموافق كلياً على جميع شروط الحجز التي وضعها مكان الإقامة، وتشمل كذلك قوانين الإلغاء وعدم الحضور، ( يمكن ان يزودك المضيف ببعض الشروط والأحكام الإضافية الخاصة عند وصولك مكان الإقامة وأي شروط أخرى تفرض عليك أثناء الإقامة أو الحجز). <br>
			يخلي الموقع المسؤولية التامة عن أي مخاطرة او اضرار او خسائر تقع على المستأجر او المضيف او أي طرف اخر ونقر باستبعاد مسؤوليتنا أو عن الاحتيال أو التحريف الاحتيالي . <br>
			يخلي الموقع المسؤولية التامة في حالة عدم التزام المستأجر او المضيف بالشروط الموضحة ادناه .
		    </div>
		    <br><br>
		    <a href="Register.php"><button class="btn4" style="width:250px; height:50px;">رجوع</button></a>
		   
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

