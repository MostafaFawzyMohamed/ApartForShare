<?php 
	session_start();
	include 'include/connection.php';
	
?> 
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>اعلاناتي</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right; width:1000px">
		<form method="post" runat="server" action="add_appartment.php" enctype="multipart/form-data">
		    <h1>اضف معلومات السكن</h1>
		    <div style="margin-right:700px;">
				<center>
					<p>اضافة صور</p>
					<img id="imageUploaded" src="img.png" alt="your image" style="width:250px; height:200px; border-radius:20px;" />
					<br>	
				<center>					
					<br><input accept="image/*" type='file' id="img" name="img" />
					<br>
					<p>نوع السكن</p>
					<input type="text" name="type" placeholder="" style="width:250px;">
				</center>
		    </div>
		    <table style="width:200px; text-align:right; margin-top:-450px;">
			<tr>
				<td>المدينة</td>
				<td>الحي</td>
				<td>الوصف</td>
				<td>الموقع</td>
			</tr>
			<tr>
				<td>
					<select name="city" style="width:175px;">
					<option value="الجميع">الجميع</option>
					<option value="الطائف">الطائف</option>
					<option value="مكة">مكة</option>
					<option value="جدة">جدة</option>
					<option value="الرياض">الرياض</option>
					</select>
				</td>
				<td>
				<select name="district" style="width:175px;">
					<option value="الجميع">الجميع</option>
					<option value="الطائف">الطائف</option>
					<option value="مكة">مكة</option>
					<option value="جدة">جدة</option>
					<option value="الرياض">الرياض</option>
				</select>
				</td>
				<td><input type="text" name="description" placeholder="" style="width:100px;"></td>
				<td><input type="text" name="location" placeholder="حدد الموقع" style="width:150px;"></td>
		    </tr>
		    <tr>
				<td>السعر</td>
				<td>المساحة</td>
				<td colspan="2">الطاقة الإستيعابيه للسكن</td>
			</tr>
			<tr>
				<td><input type="number" name="price" placeholder="" style="width:175px;"></td>
				<td><input type="number" name="area" placeholder="" style="width:175px;"></td>
				<td colspan="2"><input type="text" name="capacity" placeholder="" style="width:250px;"></td>
		    </tr>
		     <tr>
				<td>عدد الغرف</td>
				<td>عدد دورات المياة</td>
				<td colspan="2">عدد المطابخ</td>
			</tr>
			<tr>
				<td><input type="number" name="rooms" placeholder="" style="width:175px;"></td>
				<td><input type="number" name="numBath" placeholder="" style="width:175px;"></td>
				<td colspan="2"><input type="number" name="numKitchen" style="width:250px;"></td>
		    </tr>
		     <tr>
				<td colspan="4">المرافق الإضافية</td>
			</tr>
			<tr>
				<td colspan="4"><input type="text" name="additional" placeholder="" style="width:600px;"></td>
		    </tr>
		    <tr>
				<td colspan="4">تاريخ عرض الإعلان</td>
			</tr>
			<tr>
				<td colspan="2">من</td>
				<td colspan="2">إلى</td>
			</tr>
			<tr>
				<td colspan="2"><input type="date" name="dateFrom" placeholder="" style="width:250px;"></td>
				<td colspan="2"><input type="date" name="dateTo" placeholder="" style="width:250px;"></td>
		    </tr>
		    </table>
		    <input type="email" value="<?php echo $_SESSION["email"];?>" name="email" hidden>
		   <br><br><br>
		    
		    <a href="#"><button type="submit" class="btn4" style="width:250px; height:50px; margin-right:700px;">نشر الإعلان</button></a>
		 </form>
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
<script>
img.onchange = evt => {
  const [file] = img.files
  if (file) {
    imageUploaded.src = URL.createObjectURL(file)
  }
}
</script>
</body>
</html>

