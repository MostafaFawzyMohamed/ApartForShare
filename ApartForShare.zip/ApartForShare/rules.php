<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_GET['Appartment_id'])){
		$Appartment_id=$_GET['Appartment_id'];
	}
	
?>  
 <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>شروط الحجز والإلغاء</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    </div>
    <center>
    <div class="class2" >
    
     <br><br>
		<div class="text2" style="text-align:right;">
			<div class="scrollmenu">
			  <a href="Specifications.php?Appartment_id=<?php echo $Appartment_id; ?>" >المواصفات</a>
			  <a href="Rating.php?Appartment_id=<?php echo $Appartment_id; ?>">التقييمات والتعليقات</a>
			  <a href="rules.php?Appartment_id=<?php echo $Appartment_id; ?>" style="color:gray;">شروط الحجز والإلغاء</a>
			  <a href="ResidentSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>">مواصفات المقيم في السكن</a>
			  <a href="RequestSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>">قم بتحديد مواصفات شريك السكن المرغوب</a>
			  
		</div>
			<br><br>
		
		<div class="text2" style="text-align:right; margin-top:-100px; width:800px;">
		    <h1 style="color:black;">شروط الحجز والإلغاء</h1>
		    <p>
			1. الالتزام بالدين الاسلامي وما يتناسب مع العادات والتقاليد بالمملكة العربية السعودية . <br>
			2. التأكد من عدم وجود أي مخالفات في السكن والمرافق العامة والمحافظة على نظافتها. <br>
			3. الالتزام بالتقيد بموعد تسجيل الدخول والمغادرة المحدد وسيتم حساب ليلة إضافية
			في حالة التأخر عن هذا الموعد.
		    </p>
		    <br><br><br><br>
		    <center>
		   
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

