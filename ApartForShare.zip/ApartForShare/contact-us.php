<?php 
	session_start();		
?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>تواصل معنا</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body>
	 <?php
		if (isset($_SESSION["email"])) {
		$email = $_SESSION["email"];
		if ($email == "admin@roots.info") {
		    include 'include/adminHeader.php';
		} else {
			include 'include/userHeader.php';
		}
		}
	  else {
		  include 'include/header.php';
	  }
	?>
    
    
    <div class="class1">
	    <img src="pic.jpg" align="left" style="align:left; margin-left:20px; width:500px; height:500px;"/>
		<div class="text">
		    <h1> للتواصل ..</h1>
		    <h3>
			سعيا منا لخدمتكم والارتقاء بخدماتنا لتواكب تطلعاتكم يسرنا استقبال استفساراتكم وملاحظاتكم في نموذج التواصل ادناه
		   <br>&#x2709;
		   البريد الإلكتروني : admin55@gmail.com 
		   <br>&#x2706;
		   رقم الهاتف : 0505133389
		   
		   </h3>
		   
		   <br><br><br>
		</div>
	</div>
<div class="footer">
</div>
</body>
</html>

