<?php 
session_start();

if(isset($_SESSION["otp"]) and isset($_SESSION["email"])){ 
	$otp=$_SESSION["otp"];
	$email=$_SESSION["email"];
	$timeout=time()-$_SESSION["login_time_stamp"];
	if($timeout >60)  
	{
		session_unset();
		session_destroy();
		header("Location:resetpass.php");
	}
}

?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>التحقق</title>
    <meta charset="utf-8" />
    <meta http-equiv="refresh" content="60">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <div id="cat">
     <ul>
		<a href="index.php" ><img src="logo.png" align="right" style="margin-right:40px; margin-top:30px; height:150px; width:150px"></a>
		<li id="Home" class="active filter"><a href="index.php">الرئيسية</a></li>
		<li id="Services" class=" filter"><a href="about.php">من نحن</a></li>
		<li id="Contact" class=" filter"><a href="contact-us.php">تواصل معنا</a></li> 
		<li id="Login" class=" filter"><a href="Login.php">التسجيل / تسجيل الدخول</a></li> 
		<li id="" class=" filter"><a href="#">English</a></li> 
	</ul>
    </div>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
			<h1>الكود ينتهي خلال 60 ثانية :</h1>
			<span id="seconds">59</span>

		</div>
		<div class="text2" style="text-align:right;">
		    <h1>الرجاء ادخال الكود للمتابعة</h1>
		    <h4>تم ارسال كود التحقق إلى ( <?php echo $email; ?>)</h4>
		    <form method="post" name="Test" action="CheckOtpForReset.php">
				<input type="number" name="number4" placeholder=""> &nbsp;
				<input type="number" name="number3" placeholder=""> &nbsp;
				<input type="number" name="number2" placeholder=""> &nbsp;
				<input type="number" name="number1" placeholder=""> &nbsp;
		    <br><br><br><br>
		    <input type="submit" class="btn2" name="submit" value="تحقق">
		    </form>
		    <a href="sendResetCode.php?email=<?php echo $email; ?>"><button class="btn2">ارسال كود اخر</button>
		   
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
<script>
timeLeft = 59;

function countdown() {
	timeLeft--;
	document.getElementById("seconds").innerHTML = String( timeLeft );
	if (timeLeft > 0) {
		setTimeout(countdown, 1000);
	}
};

setTimeout(countdown, 1000);
</script>
</body>
</html>

