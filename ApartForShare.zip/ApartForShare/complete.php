  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>استكمال التسجيل</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <div id="cat">
     <ul>
		<a href="index.php" ><img src="logo.png" align="right" style="margin-right:40px; margin-top:30px; height:150px; width:150px"></a>
		<li id="Home" class="active filter"><a href="index.php">الرئيسية</a></li>
		<li id="Services" class=" filter"><a href="about.php">من نحن</a></li>
		<li id="Contact" class=" filter"><a href="contact-us.php">تواصل معنا</a></li> 
		<li id="Login" class=" filter"><a href="Login.php">التسجيل / تسجيل الدخول</a></li> 
		<li id="" class=" filter"><a href="#">English</a></li> 
	</ul>
    </div>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
			<h1>قم بإكمال ملفك الشخصي</h1>
			<form method="post" action="CompleteProfile.php">
			<table border=0>
			<tr>
				<td>الجنس</td>
				<td>العمر</td>
				<td>هل انت شخص مدخن؟</td>
				<td>هل تمتلك حيوان أليف؟</td>
				<td>المسمى الوظيفي</td>
			</tr>
			<tr>
				<td>
					<select name="gender">
						<option value="ذكر">ذكر</option>
						<option value="انثى">انثى</option>
					</select>
				</td>
				<td><input type="number" name="age"/></td>
				<td>
					<select name="smoke">
						<option value="نعم">نعم</option>
						<option value="لا">لا</option>
					</select>
				</td>
				<td>
					<select name="animal">
						<option value="طيور">طيور</option>
						<option value="قطة">قطة</option>
						<option value="سمكة">سمكة</option>
					</select>
				</td>
				<td>
					<select name="job">
						<option value="طالب جامعي">طالب جامعي</option>
						<option value="موظف">موظف</option>
						<option value="عاطل عن العمل">عاطل عن العمل</option>
					</select>
				</td>
			</tr>
		</table>
		<br><br>
		    <h4>رقم الجوال</h4>
		    <input type="text" name="mobile" placeholder="5xx xxx xxx"><a href="check.html"><input type="button" class="btn2" name="check" value="تحقق"></a><br>
		    <br>
		    <input type="email" value="<?php echo $_GET['email'];?>" name="email" hidden>
		    <center>
			<input type="submit" class="btn2" name="submit" value="حفظ">
			</form>
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

