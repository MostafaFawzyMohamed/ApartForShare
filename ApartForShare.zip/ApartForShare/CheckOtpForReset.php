<?php  
include 'include/connection.php';
session_start();
$otp=$_SESSION["otp"];
$email=$_SESSION["email"] ;

if (isset($_POST['number1']) and isset($_POST['number2']) and isset($_POST['number3']) and isset($_POST['number4']))
{
	$number1=$_POST['number1'];
	$number2=$_POST['number2'];
	$number3=$_POST['number3'];
	$number4=$_POST['number4'];
	$otpCheck="".$number1."".$number2."".$number3."".$number4;
	$_SESSION["email"] = $email;
	if ($otpCheck == $otp)
	{
		header("Location: reset.php?email=".$email);
	}
	else{
		header("Location: resetpass.php");
	}
}
?>
