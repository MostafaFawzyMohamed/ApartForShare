  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>تقييم المقيم</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <div id="cat">
     <ul>
		<a href="index.php" ><img src="logo.png" align="right" style="margin-right:40px; margin-top:30px; height:150px; width:150px"></a>
		<li id="Home" class="active filter"><a href="index.php">الرئيسية</a></li>
		<li id="Services" class=" filter"><a href="about.php">من نحن</a></li>
		<li id="Contact" class=" filter"><a href="contact-us.php">تواصل معنا</a></li> 
		<div class="dropdown">
		  <button class="dropbtn">المستخدم</button><img src="arrow.png" height="12px;">
		  <div class="dropdown-content">
		  <a href="profile.php">الملف الشخصي</a>
		  <a href="messages.html">&#9993; المحادثات</a>
		  <a href="advertisements.html">&#9872; اعلاناتي</a>
		  <a href="orders.html">&#128448; طلباتي</a>
		  <a href="reservations.html">&#9745; حجوزاتي</a>
		  <a href="advertisementAdd.html">&#10011; اضافة اعلان جديد</a>
		  <a href="fav.html">&#10084; المفضلة</a>
		  <a href="Logout.php">تسجيل الخروج</a>
		  </div>
		</div>
		<div class="dropdown">
			<button class="dropbtn">English</button>	
		</div>
	</ul>
    </div>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
		    <h1>تقييم المقيم في السكن</h1>
		    
		    <span class="fa fa-star checked"></span>
		    <span class="fa fa-star checked"></span>
		    <span class="fa fa-star checked"></span>
		    <span class="fa fa-star "></span>
		    <span class="fa fa-star"></span>
		    <br>
		    <strong><p style="font-size:16px;">كيف كانت تجربتك مع ياسين؟</strong>
		    <br>
		    <input type="button" class="btn4" id="rate" name="rate" value="نظيف"/>
		    <input type="button" class="btn4" id="rate" name="rate" value="موثوق"/>
		    <input type="button" class="btn4" id="rate" name="rate" value="انطوائي"/>
		    <input type="button" class="btn4" id="rate" name="rate" value="مزعج"/>
		    <strong><p style="font-size:22px;">التعليقات</strong><br>
		    <textarea id="msg" name="msg" style="width:400px; height:125px;" rows="4" cols="50">

		    </textarea>
		    <div style="margin-right:700px; width:300px; margin-top:-350px;">
			<label style="margin-right:75px;">ياسين</label><br>
			<img src="profile2.png" style="width:200px; height:200px;"/>
			<br><br><br><br>
		    <a href="#" style="color:black;"><button style="margin-right:-200px; border-radius: 15px; width:150px;">ارسال</button></p>
		   </div>
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

