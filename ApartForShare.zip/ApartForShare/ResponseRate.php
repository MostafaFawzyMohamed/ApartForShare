<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_GET['Appartment_id'])){
		$Appartment_id=$_GET['Appartment_id'];
	}
	if(isset($_GET['id'])){
		$id=$_GET['id'];
	}
	$query = "SELECT * FROM `comments` WHERE id='$id'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
?> 
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>التقييمات والتعليقات</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <center>
    <div class="class2" style="width:1250px;">
    <br><br>
		<div class="text2" style="text-align:right;">
			<div class="scrollmenu">
			  <a href="Specifications.php?Appartment_id=<?php echo $Appartment_id; ?>" >المواصفات</a>
			  <a href="Rating.php?Appartment_id=<?php echo $Appartment_id; ?>" style="color:gray;">التقييمات والتعليقات</a>
			  <a href="rules.php?Appartment_id=<?php echo $Appartment_id; ?>">شروط الحجز والإلغاء</a>
			  <a href="ResidentSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>">مواصفات المقيم في السكن</a>
			  <a href="RequestSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>">قم بتحديد مواصفات شريك السكن المرغوب</a>
			  
		</div>
			<br><br>
			<div align="right"> 
			<table border=0 class="table2" >
			<?php 
				if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
			?>
				<tr>
					<td class="td2">
						<strong><p style="font-size:20px;">
						
						<img src="profile1.png" style="height:75px;"/>
						<p style="margin-right:100px; margin-top:-75px;"><?php echo $row['name']; ?> <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						    <span class="fa fa-star checked"></span>
						<br><?php echo $row['comment']; ?></p>
					</td>
				</tr>
			</table>
			<br>
			<p>أكتب الرد هنا:</p>
			<form method="post" action="responseComment.php?Appartment_id=<?php echo $Appartment_id; ?>">
			<table border=0 class="table2" >
				<tr>
					<td class="td2">
						<strong><p style="font-size:20px;">						
						<img src="profile4.png" style="height:75px;"/>
						<textarea style="margin-right:80px; margin-top:-60px; color:gray;" id="response" name="response" rows="4" cols="50" placeholder="الرد"></textarea>
					</td>
					<input type="number" name="comment_id" value="<?php echo $id; ?>" hidden>
				</tr>
			</table>
			<br>
			<center><button type="submit" class="btn4;">ارسال الرد</button>
				<?php } } ?>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

