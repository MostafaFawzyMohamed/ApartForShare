  <?php 
	session_start();
	include 'include/connection.php';
	$user_id=0;
	$email=$_SESSION['email'];
	if(isset($_GET['Appartment_id'])){
		$Appartment_id=$_GET['Appartment_id'];	
		$sql="SELECT * FROM `ads` WHERE id='$Appartment_id'";
		mysqli_query($connect,"SET CHARACTER SET 'utf8'");
		$result = mysqli_query($connect, $sql) or die(mysqli_error($connect));
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$user_id=$row['user_id'];
			}
		}
	}
	if(isset($_POST['name']) and isset($_POST['message']) and isset($_POST['image'])){
		$name=$_POST['name'];	
		$message=$_POST['message'];
		$image=$_POST['image'];
		$time=date('Y-m-d H:i:sa');
		$sql2="INSERT INTO `messages`(`id`, `name`, `message`, `time`, `img`, `user_id`) VALUES 
							(NULL, '$name', '$message', '$time', '$image','$user_id')";	
				if (mysqli_query($connect, $sql2)) {
					echo "<script>alert('تم الإرسال بنجاح');";
					echo "window.location.href = 'accommodationRequest.php'";
					echo "</script>";
				}
				else{
					echo "<script>alert('فشل الإضافة !!');";
					echo "window.location.href = 'accommodationRequest.php'";
					echo "</script>";
				}
		 mysqli_close($connect);
	}
	
?> 
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>تواصل مع المضيف</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    </div>
		<?php
			$query = "SELECT * FROM `users` WHERE email='$email'";
			mysqli_query($connect,"SET CHARACTER SET 'utf8'");
			$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
			$name="";
			if ($result->num_rows > 0) {
				// output data of each row
				while($row = $result->fetch_assoc()) {
					$name=$row['fname'];
				}
			}
		?>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
		<form method="post" action="contactHost.php?Appartment_id=<?php echo $Appartment_id; ?>">
		
		<input type="text" name="image" value="profile1.png" hidden>
		    <h1>تواصل مع المضيف :</h1>
		    <strong><p style="font-size:27px;"><input type="text" placeholder="الإسم" name="name"></strong>
		    &nbsp;<img src="profile1.png" style="width:50px; height:50px;"/></p><br>
		    <textarea id="message" name="message" rows="4" cols="50"></textarea>
		   <center><input type="submit" style="color:black; border-radius: 10px; width:300px;" name="submit" value="ارسال رسالة"/>

		   </form>
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

