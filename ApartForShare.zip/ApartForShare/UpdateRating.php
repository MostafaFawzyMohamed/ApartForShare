<?php
	include 'include/connection.php';

	if(isset($_GET["id"]) and isset ($_GET['status']))
	{
		$id=$_GET["id"];
		$status=$_GET['status'];
		if($status==0)
			$sql="UPDATE `comments` SET `status`='مرفوض' WHERE `id`='" . $id . "'" ;
		else if($status==1)
			$sql="UPDATE `comments` SET `status`='مقبول' WHERE `id`='" . $id . "'" ;
		mysqli_query($connect,"SET CHARACTER SET 'utf8'");
		
		if (mysqli_query($connect, $sql)) {
			echo "<script>alert('تم التعديل بنجاح');";
			echo "window.location.href = 'ratings.php'";
			echo "</script>";
		} else {
			echo "<script>alert('فشل التعديل');";
			echo "window.location.href = 'ratings.php'";
			echo "</script>";
		}
		}
		mysqli_close($connect);
?>