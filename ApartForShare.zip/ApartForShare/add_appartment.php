<?php
	include 'include/connection.php';
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$appartment_id=0;
	$user_id=0;
	$email=$_POST['email'];
	$query = "SELECT id FROM `ads`";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
						$appartment_id++;
					}
	}
	$query2 = "SELECT id FROM `users` WHERE `email`='$email'";
	$result2 = mysqli_query($connect, $query2) or die(mysqli_error($connect));
	if ($result2->num_rows > 0) {
					// output data of each row
					while($row2 = $result2->fetch_assoc()) {
						$user_id=$row2['id'];
					}
	}
	$appartment_id++;	
	$city=$_POST['city'];
	$description=$_POST['description'];
	$type=$_POST['type'];
	$district=$_POST['district'];
	$location=$_POST['location'];
	$price=$_POST['price'];
	$area=$_POST['area'];
	$capacity=$_POST['capacity'];
	$rooms=$_POST['rooms'];
	$numBath=$_POST['numBath'];
	$numKitchen=$_POST['numKitchen'];
	$additional=$_POST['additional'];
	$dateFrom=$_POST['dateFrom'];
	$dateTo=$_POST['dateTo'];
	$file_Name = $_FILES['img']['name'];
	$Error = $_FILES['img']['error'];
	$file_Type = $_FILES['img']['type'];
	$file_Size = $_FILES['img']['size'];
	$data = file_get_contents($_FILES['img']['tmp_name']);
	$file = $_FILES['img']['tmp_name'];
	$Extention = explode('.', $file_Name);
	$ActualExtention = strtolower(end($Extention));
	$accept = array('jpg','gif','png','jpeg');
	$destination = 'img/' . $file_Name;
	if (in_array($ActualExtention, $accept)){
		if ($Error == 0){
			if ($file_Size < 5000000){
				$sql = "INSERT INTO `ads`(`id`, `type`, `location`, `area`, `price`, `img`, `user_id`, `status`)
					VALUES  (NULL, '$type' ,'$location','$area','$price','$destination','$user_id','معلق')";
					if(mysqli_query($connect, $sql)){
						$sql2 = "INSERT INTO `apartment`(`id`, `Appartment_id`, `description`, `city`, `District`, `location`, `price`, `area`, `capacity`, `rooms`, `numBath`, `numKitchen`, `additional`, `dateFrom`, `dateTo`)
							VALUES  (NULL, '$appartment_id', '$description' ,'$city','$district','$location','$price','$area','$capacity','$rooms','$numBath','$numKitchen','$additional','$dateFrom','$dateTo')";
						if(mysqli_query($connect, $sql2)){
							if (move_uploaded_file($file, $destination)) {
								echo "<script>alert('تم الإضافة بنجاح!');</script>";
									echo "<script>window.location='accommodationRequest.php'</script>";
							}
						} 
			}
		}		
		}
		else{
			echo "<script>alert('فشلت الإضافة !');";
			echo "window.location='requestHousing.php'";
			echo "</script>";
		}			
	}	

?>