<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_GET['Appartment_id'])){
		$Appartment_id=$_GET['Appartment_id'];
	}
	
?>  
 <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>المواصفات</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <center>
    <div class="class2" >
    
     <br><br>
		<div class="text2" style="text-align:right;">
			<div class="scrollmenu">
			  <a href="Specifications.php?Appartment_id=<?php echo $Appartment_id; ?>" style="color:gray;">المواصفات</a>
			  <a href="Rating.php?Appartment_id=<?php echo $Appartment_id; ?>">التقييمات والتعليقات</a>
			  <a href="rules.php?Appartment_id=<?php echo $Appartment_id; ?>">شروط الحجز والإلغاء</a>
			  <a href="ResidentSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>">مواصفات المقيم في السكن</a>
			  <a href="RequestSpecifications.php?Appartment_id=<?php echo $Appartment_id; ?>">قم بتحديد مواصفات شريك السكن المرغوب</a>
			  
		</div>
			<br><br>
		<?php
			$query = "SELECT * FROM `apartment` WHERE Appartment_id='$Appartment_id'";
			mysqli_query($connect,"SET CHARACTER SET 'utf8'");
			$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
			if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
		?>
		<div class="text2" style="text-align:right; margin-top:-130px; margin-right:-100px; width:800px;">
		    <h1 style="color:black;">الوصف</h1>
		    <p style="font-size:18px;">
			<?php echo $row['description']; ?>
		    </p>
		    <br>
		    <p style="font-size:18px;">
			الطاقة الاستيعابية للسكن : <?php echo $row['capacity']; ?>
		    </p>
		    <br>
		    <p style="font-size:18px;">
			المرافق الاضافية
		    </p>
		    <br>
			<table style="margin-right:700px; margin-top:-250px; width:300px; background-color:#b2b2b2; font-size:18px; border-radius:20px;">
				<tr>
					<td>تاريخ السكن</td>
					<td>تاريخ المغادرة</td>
				</tr>
				<tr>
					<td><p style="color:green;">الخميس 1 يناير 2023</p></td>
					<td><p style="color:red;">الإثنين 5 يناير 2024</p></td>
				</tr>
				<tr><td colspan="2"><br><br><a href="PayType.php?Appartment_id=<?php echo $Appartment_id; ?>"><button class="btn4" style="width:200px;" value="اكمل الدفع">اكمل الدفع</button></a><br><br></td></tr>
			
			</table>
		   <br><br>
		    <p style="font-size:18px;">
			<img src="wifi.png" style="height:25px;"/> <?php echo $row['additional']; ?>
		    </p>
		    <hr style="width:650px; margin-left:200px;">
		    <br>
		    <table style="width:400px;">
				<tr>
					<td><img src="room.png" style="height:25px;"/>&nbsp; الغرف<br><?php echo $row['rooms']; ?></td>
					<td><img src="bath.png" style="height:25px;"/>&nbsp; دورات المياة<br><?php echo $row['numBath']; ?></td>
					<td><img src="Kitchen.png" style="height:25px;"/>&nbsp; المطابخ<br><?php echo $row['numKitchen']; ?></td>
		    </table>
		   
		   <br><br><br>

		</div>
	</div>
			<?php } } ?>
	</center>
<div class="footer">
</div>
</body>
</html>

