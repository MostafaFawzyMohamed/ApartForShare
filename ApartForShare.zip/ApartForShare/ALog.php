<?php  
include 'include/connection.php';
if (isset($_POST['email']) and isset($_POST['password']))
{
	$email = $_POST['email'];
	$password = $_POST['password'];
	session_start();
	$_SESSION["email"] = $email;
	$query = "SELECT * FROM `admin` WHERE email='$email' and password='$password'";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	$count = mysqli_num_rows($result);
	if ($count == 1)
	{
		header("Location: adminPannel.php");
	}
	else{
		echo "<script>alert('Invalid Login !');";
		echo "window.location.href = 'adminLog.php'";
		echo "</script>";
	}
}
?>

