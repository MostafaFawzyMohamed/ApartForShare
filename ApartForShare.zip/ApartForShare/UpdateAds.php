<?php
	session_start();
	include 'include/connection.php';
	if(isset($_POST["specifications"]))
	{
		$id=$_GET["id"];
		$specifications= $_POST["specifications"];
		$sql="UPDATE `orders` SET `specifications`='$specifications' WHERE `id`='" . $id . "'" ;
		mysqli_query($connect,"SET CHARACTER SET 'utf8'");

	if (mysqli_query($connect, $sql)) {
		echo "<script>alert('تم التعديل بنجاح');";
		echo "window.location.href = 'UpdateAds.php?id=".$id . "'";
		echo "</script>";
	} else {
		echo "<script>alert('فشل التعديل');";
		echo "window.location.href = 'UpdateAds.php?id=".$id . "'";
		echo "</script>";
	}
	}
	mysqli_close($connect);
?>
 <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>تعديل الطلب</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <div class="vertical-menu">
		 <a href="profile.php">الملف الشخصي</a>
		 <a href="messages.php">&#9993; المحادثات</a>
		 <a href="advertisements.html">&#9872; اعلاناتي</a>
		 <a href="orders.php">&#128448; طلباتي</a>
		 <a href="reservations.html">&#9745; حجوزاتي</a>
		 <a href="advertisementAdd.html">&#10011; اضافة اعلان جديد</a>
		 <a href="fav.html">&#10084; المفضلة</a>
		 <a href="index.php">تسجيل الخروج</a>
    </div>
    <center>
    <div class="class2" style="margin-top:-650px;">
		<div class="text2" style="text-align:right;">
			<h1>تعديل الطلب</h1><br>
			<?php
				$id=$_GET['id'];
			?>
			
			<div align="right">
			<center>
			<form method="post" action="UpdateAds.php?id=<?php echo $id; ?>">
			<textarea id="w3review" name="specifications" rows="4" cols="50" placeholder="الرجاء إضافة موقع السكن في مواصفات الإعلان حتى يتم نشره"></textarea>
			<br><br>
			<input type="submit" class="btn1" style="font-size:20px; color:black" value="تعديل الطلب">
			</form>
			<a href="cancelOrder.php?id=<?php echo $id; ?>"><button class="btn1" style="font-size:20px; color:black" value="استعراض سبب الرفض">إلغاء الطلب</button></a>
			<br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

