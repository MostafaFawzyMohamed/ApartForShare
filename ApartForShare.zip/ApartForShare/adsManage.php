<?php 
	session_start();	
	include 'include/connection.php';
	$query = "SELECT * FROM `ads` WHERE status='معلق'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	
?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>ادارة الاعلانات</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/adminHeader.php'; ?>
    
    <center>
    
    
    <?php
			    if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
					

    ?>
     <br><br>
     <div class="class4" style="background-color:#b2b2b2;">
		<div class="text2" style="text-align:right;">
			<img src="<?php echo $row['img']; ?>" style="height:650px; width:700px; margin-right:-200px"/>
		</div>
	</div>
			<div class="text3" style="margin-top:-660px;">
				<strong><p style="margin-right:20px;"><?php echo $row['type']; ?><br>
				<img style="width:20px;" src="location.png"/><?php echo $row['location']; ?></strong><br>
				&nbsp; &nbsp;<i>مساحة الوحدة (<?php echo  $row['area'];?> م2)</i>
				</p>
				<br><br><br><br><br>
				<p style="margin-right:20px; color:gray">السعر</p>
				<i><p style="margin-right:20px;"><?php echo $row['price']; ?> ريال / في الشهر</p></i>
				<br><br><br>
				<div style="margin-right:105px;">
				<a href="UpdateAdsStatus.php?id=<?php echo $row['id']; ?>&status=مقبول"><button class="btn2" style="color:green;">موافقة</button></a>
				<a href="UpdateAdsStatus.php?id=<?php echo $row['id']; ?>&status=مرفوض""><button class="btn2" style="color:red;" >رفض</button></a>
			</div>
		</div>
		<?php }
			    }
			    else{
			?>
				<div class="class4" style="background-color:#b2b2b2;">
				<div class="text2" style="text-align:right;">
				<br><br>
				<center><h2 style='color:Red'>لا يوجد إعلانات لقبولها او رفضها حالياً</h2>
				<br><br>
				</div>
				</div>
				<?php
			    }
		?>
	</div>
	<br><br><br>
	 
	</center>
<div class="footer">
</div>
</body>
</html>

