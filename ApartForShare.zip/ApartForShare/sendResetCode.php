<html>
<body>
<?php
include 'include/connection.php';
function generateNumericOTP($n) { 
    $generator = "1357902468"; 
    $result = ""; 
    for ($i = 1; $i <= $n; $i++) { 
        $result .= substr($generator, (rand()%(strlen($generator))), 1); 
    }   
    // Return result 
    return $result; 
} 
if (isset($_REQUEST['email']))
//if "email" is filled out, send email
{
	$email = $_REQUEST['email'] ; 
	$sqlCheck="SELECT email FROM `users` WHERE `email`='$email'";
	$result = mysqli_query($connect, $sqlCheck) or die(mysqli_error($connect));
	if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
						$email=$row['email'];
					}
	}
	session_start();
	$_SESSION["email"] = $email;
	//send email
	include 'include/sendEmailForReset.php';
}
?>
</body>
</html>