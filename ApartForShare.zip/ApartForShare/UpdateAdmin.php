<?php
	include 'include/connection.php';

	if(isset($_POST["name"]) and isset ($_POST["mobile"]))
	{
		$id=$_GET["id"];
		$name= $_POST["name"];
		$mobile= $_POST["mobile"];
	
	$sql="UPDATE admin SET `name`='$name',
	`phone`='$mobile' WHERE `id`='" . $id . "'" ;
	if (mysqli_query($connect, $sql)) {
		echo "<script>alert('تم التعديل بنجاح');";
		echo "window.location.href = 'ManageProfile.php'";
		echo "</script>";
	} else {
		echo "<script>alert('فشل التعديل');";
		echo "window.location.href = 'ManageProfile.php'";
		echo "</script>";
	}
	}
	mysqli_close($connect);
?>