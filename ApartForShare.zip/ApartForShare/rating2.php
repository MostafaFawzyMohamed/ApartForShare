<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_GET['Appartment_id'])){
		$Appartment_id=$_GET['Appartment_id'];
	}
	if(isset($_GET['id'])){
		$id=$_GET['id'];
	}
	$query = "SELECT * FROM `residentrate` WHERE Resident_id='$id'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
?>  
 <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>التقييمات والتعليقات</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <center>
    <div class="class2" style="width:1250px;">
		<h1 style="color:white;">التقييمات والتعليقات</h1>
			<br><br><br>
			<div align="right"> 
			
			<table border=0 class="table2" >
			<?php 
				if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
			?>
				<tr>
					<td class="td2">
						<strong><p style="font-size:20px;">
						<img src="profile3.png" style="width:50px; height:50px;"/>
						<?php echo $row['name']; ?> 
						<?php if($row['rate']==5){ ?>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<?php }
							else if($row['rate']==4){
						?>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star "></span>
						<?php }
							else if($row['rate']==3){
						?>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<?php }
							else if($row['rate']==2){
						?>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<?php }
							else if($row['rate']==1){
						?>
						<span class="fa fa-star checked"></span>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<?php }
							else{
						?>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<span class="fa fa-star "></span>
						<?php } ?>
						<br>
						&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <?php echo $row['comment'] ?><br><br>
						<p style="font-size:15px; text-align:left; color:gray; margin-top:-90px;"></p>
						<a href="RateHost.php" style="font-size:25px;"><button class="button btn1" style="margin-right:700px; height:50px; width:200px;" value="رد"/>رد</button></a><br>
						<br><br>
					</td>
				</tr>
				<?php } } ?>
			</table>
			<br><br><br><br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

