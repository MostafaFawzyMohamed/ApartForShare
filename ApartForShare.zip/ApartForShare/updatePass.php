<?php
include 'include/connection.php';
mysqli_query($connect,"SET CHARACTER SET 'utf8'");
$email=$_POST['email'];
$password=$_POST['password'];
$cpass=$_POST['cpass'];
if($password==$cpass){
	$sql = "UPDATE `users` SET `password`='$password'
	WHERE `email`='$email'";
	if(mysqli_query($connect, $sql)){
		session_start();
		$_SESSION["email"] = $email;
		echo "<script>alert('Password is reset successfully!');";
		echo "window.location.href = 'index2.php'</script>";
	}
	else{
		echo "Failed";
	}
}
else{
	echo "<script>alert('Password and Confirm Password not match!');";
	echo "window.location.href = 'resetpass.php'</script>";
}



?>