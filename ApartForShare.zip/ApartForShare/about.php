<?php 
	session_start();		
?>
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>من نحن ؟</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body>
	
    <?php
		if (isset($_SESSION["email"])) {
		$email = $_SESSION["email"];
		if ($email == "admin@roots.info") {
		    include 'include/adminHeader.php';
		} else {
			include 'include/userHeader.php';
		}
		}
	  else {
		  include 'include/header.php';
	  }
    ?>
    
    <div class="class1">
	    <img src="pic.jpg" align="left" style="align:left; margin-left:20px; width:500px; height:500px;"/>
		<div class="text">
		   <h1>من نحن ؟</h1>
		   <h3>
		   نحن فريق Apart for share من خلال المثابرة والتطوير والاهتمام بالجودة قمنا بإنشاء هذا الموقع ليخدم المجال الاجتماعي والعقارات ويقوم النظام بتحقيق الربح من خلال وجود نسبة فائدة (5%) للنظام
		   </h3>
		   <br><br><br><br><br><br>
		</div>
	</div>
<div class="footer">
</div>
</body>
</html>
