<?php 
	session_start();
	include 'include/connection.php';
	if(isset($_POST['id']) and isset($_POST['Appart_id']) and isset($_POST['type'])) {
		$user_id=$_POST['id'];
		$Appart_id=$_POST['Appart_id'];
		$type=$_POST['type'];
	}
	if(isset($_POST['credit_number']) and isset($_POST['expiry_date']) and isset($_POST['CVV']) and isset($_POST['Name'])){
		$credit_number=$_POST['credit_number'];
		$expiry_date=$_POST['expiry_date'];
		$CVV=$_POST['CVV'];
		$Name=$_POST['Name'];
		$user_id=$_POST['user_id'];
		$Appart_id=$_POST['Appart_id'];
		$type=$_POST['type'];
		$sql="INSERT INTO `reservations`(`id`, `appart_id`, `Payment_type`, `credit_number`, `expiry_date`, `CVV`, `Name`, `user_id`) VALUES
			(NULL, '$Appart_id', '$type', '$credit_number', '$expiry_date', '$CVV', '$Name', '$user_id');";	
		if (mysqli_query($connect, $sql)) {
			echo "<script>alert('تم الإضافة بنجاح');";
			echo "window.location.href = 'reservations.php?Appartment_id=$Appart_id'";
			echo "</script>";
		}
		else{
			echo "<script>alert('فشل الإضافة !!');";
			echo "window.location.href = 'PayType.php?Appartment_id=$Appart_id'";
			echo "</script>";

		}
		 mysqli_close($connect);
	}
?> 
  <!DOCTYPE html>
  <html dir="rtl">

  <head>
    <title>الدفع</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body style="background-color:#485444;">
    <?php include 'include/userHeader.php'; ?>
    <center>
    <div class="class2">
		<div class="text2" style="text-align:right;">
		<form method="post" action="Pay.php">
		    <h4>رقم البطاقة *</h4>
		    <input type="text" name="credit_number" dir="LTR" placeholder="XXXX XXXX XXXX XXXX"><br>
		    <table style="width:200px">
			<tr>
				<td>تاريخ الإنتهاء *</td>
				<td>رمز الأمان *</td>
			</tr>
			<tr>
				<td><input type="month" style="color:black; border-radius:10px; width:200px;" value="2024-04" max="2030-12" name="expiry_date" placeholder="" style="width:200px;"></td>
				<td><input type="text" name="CVV" placeholder="ْْْXXX" style="width:150px;"></td>
		    
		    </table>
		    
		    <h4>اسم صاحب البطاقة *</h4>
		    <input type="text" name="Name" placeholder=""><br><br><br>
		    <input type="text" name="Appart_id" value="<?php echo $Appart_id; ?>" hidden>
		    <input type="text" name="user_id" value="<?php echo $user_id; ?>" hidden>
		    <input type="text" name="type" value="<?php echo $type; ?>" hidden>
		    
		    <a href="RateHouse.html"><button class="btn2" style="width:350px;">دفع</button></a>
		   
		   <br><br><br>
		</div>
	</div>
	</center>
<div class="footer">
</div>
</body>
</html>

