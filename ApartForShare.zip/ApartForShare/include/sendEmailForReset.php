<?php
$n = 4; 
$otp=generateNumericOTP($n);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';


$EmailSend = new PHPMailer(true);
$to = $_SESSION["email"];


try {
	$EmailSend->SMTPDebug = 2;									 
	$EmailSend->isSMTP();										 
	$EmailSend->Host	 = 'smtp.gmail.com';				 
	$EmailSend->SMTPAuth = true;							 
	$EmailSend->Username = 'apartforshare@gmail.com';				 
	$EmailSend->Password = 'azcv qycp koxj bmsm';					 
	$EmailSend->SMTPSecure = 'tls';							 
	$EmailSend->Port	 = 587; 

	$EmailSend->setFrom('apartforshare@gmail.com', 'Apart For Share');		 
	$EmailSend->addAddress($to);
	
	$EmailSend->isHTML(true);								 
	$EmailSend->Subject = 'Subject';
	$EmailSend->Body = 'Your OTP (One time Password) is : <br> <strong>'.$otp.'</strong> ';
	$EmailSend->AltBody = 'Body in plain text for non-HTML mail clients';
	$EmailSend->SMTPOptions = array(
                  'ssl' => array(
                      'verify_peer' => false,
                      'verify_peer_name' => false,
                      'allow_self_signed' => true
                  )
              );
	$EmailSend->send();
	echo "Mail has been sent successfully!";
	session_start();
	$_SESSION["email"] = $to;
	$_SESSION["otp"] = $otp;
	$_SESSION["login_time_stamp"] = time(); 
	echo "<script>alert('otp number is sent to Mail successfully!');";
	echo "window.location.href = 'CheckOtpReset.php'</script>";
} catch (Exception $e) {
	echo "Message could not be sent. Mailer Error: {$EmailSend->ErrorInfo}";
}

?>
