<?php
?>
	<div id="cat">
      <ul>
		<a href="index.php" ><img src="logo.png" align="right" style="margin-right:40px; margin-top:30px; height:150px; width:150px"></a>
		<li id="Home" class="active filter"><a href="index.php">الرئيسية</a></li>
		<li id="Services" class=" filter"><a href="about.php">من نحن</a></li>
		<li id="Contact" class=" filter"><a href="contact-us.php">تواصل معنا</a></li> 
		<li id="Login" class=" filter"><a href="Login.php">التسجيل / تسجيل الدخول</a></li>
		<li id="" class=" filter"><a href="#">English</a></li> 
	</ul>
	</div>
