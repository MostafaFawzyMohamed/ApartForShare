<?php 
$email = $_SESSION["email"];
?>
<div id="cat">
      <ul>
		<a href="index.php" ><img src="logo.png" align="right" style="margin-right:40px; margin-top:30px; height:150px; width:150px"></a>
		<li id="Home" class="active filter"><a href="index.php">الرئيسية</a></li>
		<li id="Services" class=" filter"><a href="about.php">من نحن</a></li>
		<li id="Contact" class=" filter"><a href="contact-us.php">تواصل معنا</a></li> 
		<div class="dropdown">
		  <button class="dropbtn">المستخدم</button><img src="arrow.png" height="12px;">	
		  <div class="dropdown-content">
		  <a href="profile.php">الملف الشخصي</a>
		  <a href="messages.php">&#9993; المحادثات</a>
		  <a href="advertisements.php">&#9872; اعلاناتي</a>
		  <a href="orders.php">&#128448; طلباتي</a>
		  <a href="reservations.php">&#9745; حجوزاتي</a>
		  <a href="advertisementAdd.php">&#10011; اضافة اعلان جديد</a>
		  <a href="fav.php">&#10084; المفضلة</a>
		  <a href="Logout.php">تسجيل الخروج</a>
		  
		  </div>
		</div>
		<div class="dropdown">
			<button class="dropbtn">English</button>	
		</div>
	</ul>
</div>